#include <iostream>
#include <iomanip>
#include <memory>
#include <string>
#include <fstream>
#include <deque>
#include <cstdlib>
#include <stdexcept>
#include <verilated.h>
#include <verilated_vcd_c.h>

#include "Vrv32_ooo_core.h"
#include "sim_mem.h"
#include "fp_roi_profile.h"
#include "core_roi_profile.h"
#include "fixed_time_memory.h"

// Verilator 4.x assertion diagnostics call this legacy simulation-time hook.
static uint64_t sim_time = 0;
double sc_time_stamp() { return static_cast<double>(sim_time); }

struct SimConfig {
    std::string elf_file;
    std::string vcd_file;
    std::string trace_file;
    std::string core_profile_file;
    std::string memory_audit_file;
    uint64_t core_period_ps = 0, imem_response_ps = 0, imem_interval_ps = 0, dmem_response_ps = 0;
    bool fixed_time() const { return core_period_ps != 0; }
    bool legacy_delay_selected = false;
    uint64_t max_cycles = 1000000;
    uint64_t no_retire_limit = 10000;
    int dmem_latency = 1;
    int dmem_rand_delay = 0;
    unsigned dmem_ready_period = 1;
    bool fault_store = false, fault_load = false;
    uint32_t fault_addr = 0;
    bool enable_vcd = false;
    bool enable_trace = false;
    bool profile_fp_roi = false;
};

uint64_t positive_ps(const std::string& value) {
    if (value.empty() || value.find_first_not_of("0123456789") != std::string::npos)
        throw std::invalid_argument("physical timing must be a positive integer ps value");
    uint64_t result = std::stoull(value);
    if (!result) throw std::invalid_argument("physical timing must be positive");
    return result;
}

void parse_args(int argc, char** argv, SimConfig& config) {
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg.rfind("+elf=", 0) == 0 || arg.rfind("--elf=", 0) == 0) {
            config.elf_file = arg.substr(arg.find('=') + 1);
        } else if (arg.rfind("+vcd=", 0) == 0 || arg.rfind("--vcd=", 0) == 0) {
            config.vcd_file = arg.substr(arg.find('=') + 1);
            config.enable_vcd = true;
        } else if (arg.rfind("+trace=", 0) == 0 || arg.rfind("--trace=", 0) == 0) {
            config.trace_file = arg.substr(arg.find('=') + 1);
            config.enable_trace = true;
        } else if (arg.rfind("+memory-audit=", 0) == 0) {
            config.memory_audit_file = arg.substr(arg.find('=') + 1);
        } else if (arg.rfind("+core-period-ps=", 0) == 0) {
            config.core_period_ps = positive_ps(arg.substr(arg.find('=') + 1));
        } else if (arg.rfind("+imem-response-ps=", 0) == 0) {
            config.imem_response_ps = positive_ps(arg.substr(arg.find('=') + 1));
        } else if (arg.rfind("+imem-interval-ps=", 0) == 0) {
            config.imem_interval_ps = positive_ps(arg.substr(arg.find('=') + 1));
        } else if (arg.rfind("+dmem-response-ps=", 0) == 0) {
            config.dmem_response_ps = positive_ps(arg.substr(arg.find('=') + 1));
        } else if (arg == "+profile-fp-roi") {
            config.profile_fp_roi = true;
        } else if (arg.rfind("+profile-core-roi=", 0) == 0) {
            config.core_profile_file = arg.substr(arg.find('=') + 1);
            config.profile_fp_roi = true;
        } else if (arg.rfind("+max-cycles=", 0) == 0) {
            config.max_cycles = std::stoull(arg.substr(arg.find('=') + 1));
        } else if (arg.rfind("+no-retire-max=", 0) == 0) {
            config.no_retire_limit = std::stoull(arg.substr(arg.find('=') + 1));
        } else if (arg.rfind("+dmem-latency=", 0) == 0 || arg.rfind("--dmem-latency=", 0) == 0) {
            config.legacy_delay_selected = true;
            config.dmem_latency = std::stoi(arg.substr(arg.find('=') + 1));
        } else if (arg.rfind("+dmem-ready-period=", 0) == 0) {
            config.dmem_ready_period = std::stoul(arg.substr(arg.find('=') + 1));
            if (config.dmem_ready_period == 0) throw std::invalid_argument("ready period must be positive");
        } else if (arg.rfind("+dmem-fault-store=", 0) == 0 || arg.rfind("+dmem-fault-load=", 0) == 0) {
            config.fault_store = arg.rfind("+dmem-fault-store=", 0) == 0;
            config.fault_load = !config.fault_store;
            config.fault_addr = std::stoul(arg.substr(arg.find('=') + 1), nullptr, 0);
        } else if (arg.rfind("+dmem-rand-delay=", 0) == 0 || arg.rfind("--dmem-rand-delay=", 0) == 0) {
            config.legacy_delay_selected = true;
            config.dmem_rand_delay = std::stoi(arg.substr(arg.find('=') + 1));
        }
    }
}

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);

    SimConfig config;
    try {
        parse_args(argc, argv, config);
        bool any_time = config.core_period_ps || config.imem_response_ps || config.imem_interval_ps || config.dmem_response_ps;
        if (any_time && !(config.core_period_ps && config.imem_response_ps && config.imem_interval_ps && config.dmem_response_ps))
            throw std::invalid_argument("fixed time requires core-period, imem-response, imem-interval and dmem-response in ps");
        if (any_time && config.legacy_delay_selected)
            throw std::invalid_argument("fixed physical time cannot be mixed with cycle latency/random delay options");
        if (any_time && config.max_cycles > UINT64_MAX / config.core_period_ps)
            throw std::invalid_argument("physical simulation duration overflow");
    } catch (const std::exception& e) {
        std::cerr << "Invalid simulator arguments: " << e.what() << std::endl;
        return 2;
    }

    if (config.elf_file.empty()) {
        std::cout << "Usage: " << argv[0] << " +elf=<path.elf> [+vcd=<path.vcd>] [+trace=<path.log>] [+max-cycles=N]" << std::endl;
        return 1;
    }

    SimMemory memory;
    uint32_t entry_pc = 0x80000000;
    if (!memory.load_elf(config.elf_file, entry_pc)) {
        std::cerr << "Failed to load ELF: " << config.elf_file << std::endl;
        return 1;
    }

    if (config.enable_vcd) {
        Verilated::traceEverOn(true);
    }

    auto top = std::make_unique<Vrv32_ooo_core>();

    std::unique_ptr<VerilatedVcdC> tfp;
    if (config.enable_vcd) {
        tfp = std::make_unique<VerilatedVcdC>();
        top->trace(tfp.get(), 99);
        tfp->open(config.vcd_file.c_str());
        std::cout << "[Simulator] VCD tracing enabled: " << config.vcd_file << std::endl;
    }

    std::ofstream trace_out;
    if (config.enable_trace) {
        trace_out.open(config.trace_file);
        std::cout << "[Simulator] Commit trace logging enabled: " << config.trace_file << std::endl;
    }

    uint64_t cycles = 0;
    uint64_t retired_insns = 0;
    uint64_t last_retire_cycle = 0;
    FpRoiProfile fp_roi;
    CoreRoi::Profile core_roi;
    std::ofstream core_profile_out;
    if (!config.core_profile_file.empty()) {
        core_profile_out.open(config.core_profile_file);
        if (!core_profile_out) {
            std::cerr << "Cannot open core ROI profile: " << config.core_profile_file << std::endl;
            return 1;
        }
    }

    // Reset sequence: initialize pins and hold rst=1 for 10 cycles
    top->clk = 0;
    top->rst = 1;
    top->imem_req_ready = 1;
    top->imem_rsp_valid = 0;
    top->imem_rsp_rdata = 0;
    top->imem_rsp_error = 0;
    top->dmem_req_ready = 1;
    top->dmem_rsp_valid = 0;
    top->dmem_rsp_rdata = 0;
    top->dmem_rsp_error = 0;

    for (int i = 0; i < 10; ++i) {
        top->clk = 0;
        top->eval();
        if (tfp) tfp->dump(sim_time);
        ++sim_time;
        top->clk = 1;
        top->eval();
        if (tfp) tfp->dump(sim_time);
        ++sim_time;
    }
    top->rst = 0;

    // Memory pipeline state (Synchronous 1-cycle latency SRAM model)
    bool imem_pipe_valid = false;
    uint32_t imem_pipe_data = 0;

    struct DMemQueueEntry {
        uint32_t data;
        int delay;
        bool error;
    };
    std::deque<DMemQueueEntry> dmem_q;
    FixedTimePort timed_i(config.fixed_time() ? config.imem_response_ps : 1,
                          config.fixed_time() ? config.imem_interval_ps : 1, 4);
    FixedTimePort timed_d(config.fixed_time() ? config.dmem_response_ps : 1,
                          config.fixed_time() ? config.dmem_response_ps : 1, 1);
    uint32_t minimum_sp = SimMemory::RAM_BASE + SimMemory::RAM_SIZE;
    bool stack_seen = false;

    bool fault_issued = false;
    uint64_t fault_responses = 0, blocked_load_cycles = 0, blocked_store_cycles = 0;
    bool exit_pending = false;
    int exit_drain_cycles = 0;

    std::cout << "[Simulator] Starting simulation run..." << std::endl;

    while (!Verilated::gotFinish() && cycles < config.max_cycles) {
        if (memory.has_exited()) {
            if (!exit_pending) {
                exit_pending = true;
                exit_drain_cycles = 50;
            } else if (exit_drain_cycles <= 0) {
                break;
            }
            exit_drain_cycles--;
        }

        // --- Falling Edge (Clock Low) ---
        top->clk = 0;

        // Drive response and ready to core. Fixed-time ports retain accepted
        // transactions across redirects and never return data before due_ps.
        const uint64_t now_ps = config.fixed_time() ? cycles * config.core_period_ps : 0;
        top->imem_req_ready = config.fixed_time() ? timed_i.ready(now_ps) : 1;
        top->imem_rsp_valid = config.fixed_time() ? timed_i.valid(now_ps) : imem_pipe_valid;
        top->imem_rsp_rdata = config.fixed_time() ? (timed_i.valid(now_ps) ? timed_i.front().data : 0) : imem_pipe_data;
        top->imem_rsp_error = 0;

        const bool dmem_idle = config.fixed_time() ? timed_d.empty() : dmem_q.empty();
        top->dmem_req_ready = (config.fixed_time() ? timed_d.ready(now_ps) : dmem_q.empty()) && cycles % config.dmem_ready_period == 0;
        bool dmem_rsp_drive = config.fixed_time() ? timed_d.valid(now_ps) : (!dmem_q.empty() && dmem_q.front().delay <= 0);
        top->dmem_rsp_valid = dmem_rsp_drive ? 1 : 0;
        top->dmem_rsp_rdata = dmem_rsp_drive ? (config.fixed_time() ? timed_d.front().data : dmem_q.front().data) : 0;
        top->dmem_rsp_error = dmem_rsp_drive && (config.fixed_time() ? timed_d.front().error : dmem_q.front().error);

        top->eval();
        if (tfp) tfp->dump(sim_time);
        ++sim_time;

        if (core_profile_out.is_open() && fp_roi.active) core_roi.sample(CoreRoi::read(*top));

        // Sample memory requests from core
        bool imem_accepted = (top->imem_req_valid && top->imem_req_ready);
        uint32_t next_imem_data = imem_accepted ? memory.read32(top->imem_req_addr) : 0;
        bool next_imem_valid = imem_accepted;
        if (config.fixed_time()) {
            if (top->imem_rsp_valid && top->imem_rsp_ready) timed_i.consume(now_ps);
            if (imem_accepted) timed_i.accept(now_ps, next_imem_data);
        }

        if (top->dmem_req_valid && !top->dmem_req_ready && dmem_idle) {
            if (top->dmem_req_wen) ++blocked_store_cycles;
            else ++blocked_load_cycles;
        }

        // D-memory response handshake
        if (top->dmem_rsp_valid && top->dmem_rsp_ready) {
            if (top->dmem_rsp_error) ++fault_responses;
            if (config.fixed_time()) timed_d.consume(now_ps);
            else dmem_q.pop_front();
        }

        // D-memory request handshake
        bool dmem_accepted = (top->dmem_req_valid && top->dmem_req_ready);
        if (dmem_accepted) {
            DMemQueueEntry entry;
            entry.error = !fault_issued && top->dmem_req_addr == config.fault_addr &&
                ((config.fault_store && top->dmem_req_wen) || (config.fault_load && !top->dmem_req_wen));
            if (entry.error) {
                fault_issued = true;
                entry.data = 0;
                std::cout << "[Dmem environment] injected " << (top->dmem_req_wen ? "store" : "load")
                          << " fault addr=0x" << std::hex << top->dmem_req_addr << std::dec << std::endl;
            } else if (top->dmem_req_wen) {
                memory.write32(top->dmem_req_addr, top->dmem_req_wdata, top->dmem_req_byte_en);
                entry.data = 0;
            } else {
                entry.data = memory.read32(top->dmem_req_addr);
            }
            int lat = config.dmem_latency;
            if (config.dmem_rand_delay > 0) {
                lat += (std::rand() % (config.dmem_rand_delay + 1));
            }
            entry.delay = lat;
            if (config.fixed_time()) timed_d.accept(now_ps, entry.data, entry.error);
            else dmem_q.push_back(entry);
        }

        // --- Rising Edge (Clock High) ---
        top->clk = 1;
        top->eval();
        if (tfp) tfp->dump(sim_time);
        ++sim_time;

        for (auto& entry : dmem_q) {
            if (entry.delay > 0) entry.delay--;
        }

        imem_pipe_valid = next_imem_valid;
        imem_pipe_data  = next_imem_data;

        cycles++;

        // Commit trace inspection (commit_trace_t 344-bit layout, MSB-first)
        bool retire_valid = (top->commit_trace[10] >> 23) & 1;
        bool trap_valid   = (top->commit_trace[10] >> 22) & 1;
        uint32_t commit_pc = ((top->commit_trace[8] & 0x3FFFFF) << 10) | ((top->commit_trace[7] >> 22) & 0x3FF);
        uint32_t commit_insn = ((top->commit_trace[7] & 0x3FFFFF) << 10) | ((top->commit_trace[6] >> 22) & 0x3FF);
        if (core_profile_out.is_open()) core_roi.finish_cycle(retire_valid, commit_pc, commit_insn);

        if (retire_valid) {
            retired_insns++;
            last_retire_cycle = cycles;

            if (config.profile_fp_roi) fp_roi.observe(commit_insn);
            bool     int_dst_valid = (top->commit_trace[6] >> 21) & 1;
            uint32_t int_dst_arch  = (top->commit_trace[6] >> 16) & 0x1F;
            uint32_t int_dst_data  = ((top->commit_trace[6] & 0xFFFF) << 16) | ((top->commit_trace[5] >> 16) & 0xFFFF);
            if (int_dst_valid && int_dst_arch == 2) {
                stack_seen = true;
                minimum_sp = std::min(minimum_sp, int_dst_data);
            }
            bool     fp_dst_valid  = (top->commit_trace[5] >> 15) & 1;
            uint32_t fp_dst_arch   = (top->commit_trace[5] >> 10) & 0x1F;
            uint32_t fp_dst_data   = ((top->commit_trace[5] & 0x3FF) << 22) | ((top->commit_trace[4] >> 10) & 0x3FFFFF);
            bool     mem_valid     = (top->commit_trace[4] >> 9) & 1;
            uint32_t mem_addr      = ((top->commit_trace[4] & 0x1FF) << 23) | ((top->commit_trace[3] >> 9) & 0x7FFFFF);
            uint32_t mem_byte_mask = (top->commit_trace[3] >> 5) & 0xF;
            uint32_t mem_wdata     = ((top->commit_trace[3] & 0x1F) << 27) | ((top->commit_trace[2] >> 5) & 0x7FFFFFF);

            if (config.enable_trace && trace_out.is_open()) {
                trace_out << "core 0: 0x" << std::hex << std::setw(8) << std::setfill('0') << commit_pc
                          << " (0x" << std::setw(8) << std::setfill('0') << commit_insn << ")";
                if (int_dst_valid) {
                    trace_out << " x" << std::dec << int_dst_arch << "=0x" << std::hex << int_dst_data;
                }
                if (fp_dst_valid) {
                    trace_out << " f" << std::dec << fp_dst_arch << "=0x" << std::hex << fp_dst_data;
                }
                if (mem_valid) {
                    trace_out << " [mem=0x" << std::hex << mem_addr << " mask=0x" << mem_byte_mask << " data=0x" << mem_wdata << "]";
                }
                trace_out << std::dec << std::endl;
            }

            if (exit_pending && commit_insn == 0x10500073 /* wfi */) {
                break;
            }
        }

        if (trap_valid) {
            uint32_t trap_pc = ((top->commit_trace[8] & 0x3FFFFF) << 10) | ((top->commit_trace[7] >> 22) & 0x3FF);
            uint32_t trap_insn = ((top->commit_trace[7] & 0x3FFFFF) << 10) | ((top->commit_trace[6] >> 22) & 0x3FF);
            uint32_t trap_cause = ((top->commit_trace[2] & 0x1F) << 27) | ((top->commit_trace[1] >> 5) & 0x7FFFFFF);
            uint32_t trap_tval  = ((top->commit_trace[1] & 0x1F) << 27) | ((top->commit_trace[0] >> 5) & 0x7FFFFFF);
            std::cout << "[Simulator] TRAP encountered at cycle " << cycles << " PC=0x" << std::hex << trap_pc
                      << " insn=0x" << trap_insn << " cause=0x" << trap_cause << " tval=0x" << trap_tval << std::dec << std::endl;
            last_retire_cycle = cycles;
        }

        // Watchdog timeout check
        if (cycles - last_retire_cycle > config.no_retire_limit) {
            std::cerr << "\n[Simulator] ERROR: Watchdog timeout! No instruction retired for "
                      << config.no_retire_limit << " cycles. (Current cycle: " << cycles << ")" << std::endl;
            break;
        }
    }

    if (tfp) {
        tfp->close();
    }
    if (trace_out.is_open()) {
        trace_out.close();
    }
    if (core_profile_out.is_open()) core_roi.write(core_profile_out);

    if (config.dmem_ready_period != 1 || config.fault_store || config.fault_load) {
        std::cout << "DMEM ENV blocked_load_cycles=" << blocked_load_cycles
                  << " blocked_store_cycles=" << blocked_store_cycles
                  << " fault_requests=" << fault_issued << " fault_responses=" << fault_responses << std::endl;
    }

    if (!config.memory_audit_file.empty()) {
        std::ofstream audit(config.memory_audit_file);
        if (!audit) { std::cerr << "Cannot open memory audit" << std::endl; return 2; }
        audit << "{\n  \"fixed_time\": " << (config.fixed_time() ? "true" : "false")
              << ",\n  \"core_period_ps\": " << config.core_period_ps
              << ",\n  \"imem_response_ps\": " << config.imem_response_ps
              << ",\n  \"imem_interval_ps\": " << config.imem_interval_ps
              << ",\n  \"dmem_response_ps\": " << config.dmem_response_ps
              << ",\n  \"imem_requests\": " << timed_i.requests << ",\n  \"imem_responses\": " << timed_i.responses
              << ",\n  \"dmem_requests\": " << timed_d.requests << ",\n  \"dmem_responses\": " << timed_d.responses
              << ",\n  \"imem_min_response_ps\": " << (timed_i.responses ? timed_i.min_response_ps : 0)
              << ",\n  \"imem_max_response_ps\": " << timed_i.max_response_ps
              << ",\n  \"dmem_min_response_ps\": " << (timed_d.responses ? timed_d.min_response_ps : 0)
              << ",\n  \"dmem_max_response_ps\": " << timed_d.max_response_ps
              << ",\n  \"imem_max_handoff_ps\": " << timed_i.max_handoff_ps
              << ",\n  \"dmem_max_handoff_ps\": " << timed_d.max_handoff_ps
              << ",\n  \"stack_pointer_seen\": " << (stack_seen ? "true" : "false")
              << ",\n  \"minimum_retired_sp\": " << minimum_sp
              << ",\n  \"maximum_stack_bytes_from_sp\": " << (stack_seen ? SimMemory::RAM_BASE + SimMemory::RAM_SIZE - minimum_sp : 0)
              << "\n}\n";
    }

    double ipc = (cycles > 0) ? (static_cast<double>(retired_insns) / cycles) : 0.0;

    if (config.profile_fp_roi) {
        std::cout << "FP ROI cycle_reads=" << std::dec << fp_roi.cycle_reads
                  << " retired=" << fp_roi.retired
                  << " fmadd_s=" << fp_roi.fused[0] << " fmsub_s=" << fp_roi.fused[1]
                  << " fnmsub_s=" << fp_roi.fused[2] << " fnmadd_s=" << fp_roi.fused[3] << std::endl;
    }

    std::cout << "\n================ Simulation Summary ================" << std::endl;
    std::cout << "  ELF binary     : " << config.elf_file << std::endl;
    std::cout << "  Cycles         : " << cycles << std::endl;
    std::cout << "  Retired insns  : " << retired_insns << std::endl;
    std::cout << "  IPC            : " << std::fixed << std::setprecision(4) << ipc << std::endl;
    std::cout << "  Exit status    : " << (memory.has_exited() ? (memory.exit_code() == 0 ? "PASS (0)" : "FAIL") : "TIMEOUT / HALTED") << std::endl;
    std::cout << "====================================================\n" << std::endl;

    return memory.has_exited() ? memory.exit_code() : 1;
}
