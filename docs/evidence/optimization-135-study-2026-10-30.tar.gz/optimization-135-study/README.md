# Directions 1/3/5 diagnostic evidence — 2026-10-30

81 retained reference cases; 27 observer off/on pairs (54 fresh runs); 6 actual instruction controls (18 runs); 6 deliberate adapter corruption checks. No new CPU RTL or full-suite score. A same-flow native physical run is outstanding.

B results are accepted from observer-v1/B; baseline and A from observer-v2. The v1 baseline/A attempt stopped because the ELF path label moved from /workspace to /workspace/rv32_000. v2 verifies that label and compares every other output byte. No failed attempt was relabelled as passed.

Run `python3 source/verify_study_archive.py .` here to verify every stored/decoded payload and reference/observer comparisons. `SHA256SUMS` also covers archive metadata. `input-aliases.json` maps original source paths to stored, optionally gzip-compressed input snapshots. This bundle captures source bytes while the observer changes were uncommitted; it is a read-only diagnostic experiment, not a clean-commit architectural qualification.

The frozen B archive remains unchanged; its 1327 stored/decoded entries were independently checked again. Working ODB/route-guide compression receipts under environment describe exact restoration.
